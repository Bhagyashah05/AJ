x=input("enter number")
print(x)