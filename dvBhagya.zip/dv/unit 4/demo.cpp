#include <bits/stdc++.h>
using namespace std;
int main(){
    int x;
    cin>>x;
    cout<<x;

}
