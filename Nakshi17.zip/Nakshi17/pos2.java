<head>
<title>Positioning2</title>

<style>
	div.d
	{
		position:fixed;
		top:0;
		right:0;
	}
	div.e
	{
		height:100px;
		overflow:scroll;
		background-color:pink;
	}
</style>
</head>

<body>
<div class='d'>I am Fixed</div><br>
<div class='e'>
<p>This is Text........<br>
	This is Text....<br>
<pre>











</pre>
</p>
</div>
<div class='f'></div>
<div class='g'></div>
<div class='h'></div>

</body>