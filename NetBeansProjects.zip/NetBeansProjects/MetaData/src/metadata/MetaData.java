/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metadata;
import java.net.*;
import java.util.*;
import java.io.*;
import java.sql.*;

/**
 *
 * @author ljeng
 */
public class MetaData {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        String url="jdbc:mysql://localhost:3306/Bank";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection(url,"root","");
        if (conn!=null)
        {
            System.out.println("Connected!!");
        }
    }
    
    String sql="Select * from Bank_inf1";
    Statement st;
    st = conn.createStatement();
    ResultSet rs;
    rs=st.executeQuery(sql);
    ResultSetMetaData rsmd=rs.getMetaData();
    System.out.println(rsmd.getColumnName(1));
    
    
    
}
