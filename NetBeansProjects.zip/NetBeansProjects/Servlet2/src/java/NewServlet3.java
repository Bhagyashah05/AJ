import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.*;
import java.io.*;

public class NewServlet3 extends HttpServlet
{
    public void init()
    {
        System.out.println("Init Called");
    }
    public void service(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
    {
        String msg;
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();
        ServletContext cf=getServletContext();
        msg=cf.getInitParameter("ABC");
        out.println(msg);
    }
    public void destroy()
    {
        System.out.println("destroy Servlet");
    }
}