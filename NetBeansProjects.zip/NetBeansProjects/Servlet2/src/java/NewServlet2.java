import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.*;
import java.io.*;
public class NewServlet2 extends HttpServlet
{
    public void init()
    {
        System.out.println("Init Called");
    }
    public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();
        int a=Integer.parseInt(req.getParameter("t1"));
        int b=Integer.parseInt(req.getParameter("t2"));
        int c=a+b;
        out.println("Ans is "+c);
    }
    public void destroy()
    {
        System.out.println("destroy Servlet");
    }
}