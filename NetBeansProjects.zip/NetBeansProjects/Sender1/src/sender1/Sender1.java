/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ;
import java.net.*;
import java.io.*;
import java.util.*;


/**
 *
 * @author ljeng
 */
public class Sender1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception
    {
        DatagramSocket ds=new DatagramSocket(2345);
        
        byte[] sd=new byte[50];
        String msg="Hellooo";
        InetAddress inet=InetAddress.getLocalHost();
        DatagramPacket dp=new DatagramPacket (sd,sd.length,inet,2346);
        ds.send(dp);
    }
    
}
