import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.*;
import java.io.*;

public class NewServlet5 extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter out=res.getWriter();
       
        String unn=req.getParameter("un");
        String pwd=req.getParameter("p");
        if(unn.equals("admin")&& pwd.equals("admin"))
                {
                   out.println("Inside Forward");
                   RequestDispatcher rd=req.getRequestDispatcher("NewServlet6");
                   rd.forward(req, res);
                           
                }
        else
        {
          out.println("Inside include");
          RequestDispatcher rd=req.getRequestDispatcher("index.html");
          rd.include(req,res);
          
        }
    }
}