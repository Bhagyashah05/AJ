import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.*;
import java.io.*;
public class NewServlet extends HttpServlet
{
    public void init()
    {
        System.out.println("Init Called");
    }
    public void service(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
    {
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();
        String msg="Service Method :Hii My name is Nakshi.";
        out.println("<h1>"+msg+"</h1>");
        
    }
    public void destroy()
    {
        System.out.println("destroy Servlet");
    }
}