/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc_employee;
import java.sql.*;
import java.util.*;
import java.io.*;
import java.net.*;

/**
 *
 * @author ljeng
 */
public class JDBC_Employee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        String url="jdbc:mysql://localhost:3306/employee";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection(url,"root","");
        if (conn!=null)
        {
            System.out.println("Connected!!");
        }
        
        /*String sql="Create table emp3 (name varchar(10),age int(10)) ";
        Statement st;
        st=conn.createStatement();
        st.executeUpdate(sql);
        System.out.println("Table Created");*/
        
        String sql1="Insert into emp3 values(?,?)";
        PreparedStatement pst;
        pst=conn.prepareStatement(sql1);
        String name[]={"Ram","Shyam","Prit"};
        int age[]={10,20,30};
        for (int i=0; i<name.length;i++)
        {
            pst.setString(1,name[i]);
            pst.setInt(2,age[i]);
            int r=pst.executeUpdate();
        }
       
        System.out.println("Success!!");
        
        CallableStatement cst;
        cst=conn.prepareCall("CALL cp()");
        cst.executeUpdate();
        System.out.println("Done");
        
    }
    
}
