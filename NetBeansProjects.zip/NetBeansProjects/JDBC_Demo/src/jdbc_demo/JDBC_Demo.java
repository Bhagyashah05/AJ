/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc_demo;
import java.sql.*;

/**
 *
 * @author ljeng
 */
public class JDBC_Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        String url="jdbc:mysql://localhost:3306/Student_db";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection(url,"root","");
        if (conn!=null)
        {
            System.out.println("Connected!!");
                    
        }  
        /*String sql2="Create table s_into (id int(10),name varchar(10),division varchar(50))";
        Statement st;
        st=conn.createStatement();
        st.executeUpdate(sql);
        System.out.println("Values Added");
        */
       
        /*String sql1="Insert into s_into values(23,'Nakshi','A')";
        Statement st;
        st=conn.createStatement();
        st.executeUpdate(sql);
        System.out.println("Values Added");*/
        
        String sql="Update s_into set name='Bunny' where id=23";
        String sql1="Delete from s_into where id=23";
        String sql2="Drop table s_into";
        Statement st;
        st=conn.createStatement();
        st.executeUpdate(sql);
        st.executeUpdate(sql1);
        st.executeUpdate(sql);
        System.out.println("Success!!");
        
        
    }
    
}
