/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package updatingmethods;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;

/**
 *
 * @author ljeng
 */
public class UpdatingMethods {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        String url="jdbc:mysql://localhost:3306/employee";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection(url,"root","");
        if (conn!=null)
        {
            System.out.println("Connected!!");
        }
        
        String sql="Select * from emp3";
        Statement st;
        st=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        
        ResultSet rs;
        rs=st.executeQuery(sql);
        while(rs.next())
        {
            int r=rs.getInt(2)+5;
            rs.updateInt(2,r);
            rs.updateRow();
            System.out.println("Age:"+rs.getInt(2));
        }
        
        
    }
    
}
