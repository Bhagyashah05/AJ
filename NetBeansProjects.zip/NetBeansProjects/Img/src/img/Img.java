/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package img;
import java.net.*;
import java.util.*;
import java.io.*;
import java.sql.*;


/**
 *
 * @author ljeng
 */
public class Img {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
        // TODO code application logic here
        
        String url="jdbc:mysql://localhost:3306/Bank";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection(url,"root","");
        if (conn!=null)
        {
            System.out.println("Connected!!");
        }
        
        /*String sql="Create table IMG(image longblob)";
        Statement st;
        st=conn.createStatement();
        st.executeUpdate(sql);
        System.out.println("Table Created!!");*/
        
        String sql1="Insert into IMG values(?)";
        PreparedStatement pst;
        pst=conn.prepareStatement(sql1);
        File mf=new File("C:\\Users\\ljeng\\Pictures\\Screenshots\\desk.png");
        FileInputStream fis=new FileInputStream(mf);
        pst.setBinaryStream(1,fis,mf.length());
        pst.executeUpdate();
        System.out.println("Img printed");
    }
    
}
