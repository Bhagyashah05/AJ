/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingapp;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;
/**
 *
 * @author ljeng
 */
public class BankingApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
        // TODO code application logic here
        String url="jdbc:mysql://localhost:3306/Bank";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection(url,"root","");
        if (conn!=null)
        {
            System.out.println("Connected!!");
        }
        
        /*String sql="Create table Bank_inf1(acc_no int(10),cust_name varchar(20),phone int(12),address varchar(20))";
        Statement st;
        st=conn.createStatement();
        st.executeUpdate(sql);
        System.out.println("Table Created!!");
        
        String sql1="Insert into Bank_inf1 values(?,?,?,?)";
        
        PreparedStatement ps;
        ps=conn.prepareStatement(sql1);
        
        int acc[]={123456,7891011,3456789,456789,1209876};
        int phn[]={26751818,9913001,904567,985678,8769045};
        String cn[]={"Nakshi","Naku","prit","Sita","Geeta"};
        String ad[]={"abc","xyz","pqr","rst","lmn"};
        
        for(int i=0; i<acc.length;i++)
        {
            ps.setInt(1,acc[i]);
            ps.setInt(3,phn[i]);
            ps.setString(2,cn[i]);
            ps.setString(4,ad[i]);
            
            int r=ps.executeUpdate();
        }
        
        System.out.println("Success!!");*/
        
        
        String sql="Select * from Bank_inf1";
        Statement st;
        st=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rst=st.executeQuery(sql);
        while(rst.next())
        {
            if(rst.getInt(1)>456789)
            {   int r=rst.getInt(1)+40;
                rst.updateInt(1,r);
                rst.updateRow();
               System.out.println("ACC are:"+rst.getInt(1));
            }   
        }
        
         System.out.println("Displayed!!");
        
        String sql2="Update Bank_inf1 set cust_name=? where acc_no=?";
        PreparedStatement pst;
        pst=conn.prepareStatement(sql2);
        pst.setString(1,"Ram");
        pst.setInt(2,123456);
        int r=pst.executeUpdate();
        System.out.println("Updated!!");
        
        

        
        
    }
    
}
